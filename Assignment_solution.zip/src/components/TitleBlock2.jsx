import React from 'react'

export const TitleBlock2 = () => {
  return (
    <>
    
    <div className='bg-white'>
        <h1 className='text-violet-500'>Our programs</h1>
        <p className='text-black'>Types of partnerships</p>
        <p className='text-black'>programs</p>
    </div>
</>
  )
}
