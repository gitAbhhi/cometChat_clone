import React from 'react'

export const CustormerSection = () => {
  return (
<>
<ul className='flex p-[30px] bg-gray-900 text-gray-500 justify-between'>
    <li><img src="" alt="aws" /></li>
    <li><img src="" alt="10X GENOMICS" /></li>
    <li><img src="" alt="Microsoft" /></li>
    <li><img src="" alt="NASSCOM" /></li>
    <li><img src="" alt="techstars_" /></li>
    <li><img src="" alt="tekno point" /></li>
    <li><img src="" alt="cisco" /></li>
    <li><img src="" alt="trinax" /></li>

</ul>
</>
  )
}
